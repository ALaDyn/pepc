echo "Laser test  ..."
cp laser.h run.h
#mpirun -np 1 ../src/pepc 
llrun -p 1 ../src/pepck 
eval `cat runstamp |  awk '{ t = $1;  printf  "TEND=%s",t}'`
cp energy.dat log/energy.$TEND
cp run.out log/run.$TEND
echo "... done"
