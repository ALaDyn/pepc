echo "Starting PEPC-B: ion config "
cp clamp.h run.h
llrun  -p4 ../pepc-b/pepcb 
echo "... done" 
