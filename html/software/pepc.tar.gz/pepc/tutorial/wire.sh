echo "Starting PEPC-B: wire target ..."
cp wire.h run.h
llrun  -p8 ../pepc-b/pepcb 
echo "... done" 
