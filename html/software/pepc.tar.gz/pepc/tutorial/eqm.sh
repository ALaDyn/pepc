echo "Starting PEPC-B: clamped eqm ..."
cp eqm.h run.h
llrun  -p4 ../pepc-b/pepcb 
echo "... done" 
