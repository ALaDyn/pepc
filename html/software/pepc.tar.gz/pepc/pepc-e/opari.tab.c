#include "pomp_lib.h"


#include "physvars.f90.opari.inc"
#include "utils.f90.opari.inc"
#include "setup.f90.opari.inc"
#include "stamp.f90.opari.inc"
#include "configure.f90.opari.inc"
#include "face.f90.opari.inc"
#include "cutvector.f90.opari.inc"
#include "randion.f90.opari.inc"
#include "maxwell1.f90.opari.inc"
#include "special_start.f90.opari.inc"
#include "cold_start.f90.opari.inc"
#include "scramble_v.f90.opari.inc"
#include "forces.f90.opari.inc"
#include "force_direct.f90.opari.inc"
#include "error_test.f90.opari.inc"
#include "velocities.f90.opari.inc"
#include "push.f90.opari.inc"
#include "energy_cons.f90.opari.inc"
#include "potenergy.f90.opari.inc"
#include "kinenergy.f90.opari.inc"
#include "param_dump.f90.opari.inc"
#include "open_files.f90.opari.inc"
#include "close_files.f90.opari.inc"
#include "pepce.f90.opari.inc"

int POMP_MAX_ID = 1;

struct ompregdescr* pomp_rd_table[1] = {
  0,
};
