#include "pomp_lib.h"


#include "treevars.f90.opari.inc"
#include "tree_utils.f90.opari.inc"
#include "utils.f90.opari.inc"
#include "tree_domains.f90.opari.inc"
#include "setup_treearrays.f90.opari.inc"
#include "tree_build.f90.opari.inc"
#include "tree_branches.f90.opari.inc"
#include "tree_fill.f90.opari.inc"
#include "tree_properties.f90.opari.inc"
#include "tree_walk.f90.opari.inc"
#include "tree_prefetch.f90.opari.inc"
#include "sum_force.f90.opari.inc"
#include "sum_bfield.f90.opari.inc"
#include "tree_update.f90.opari.inc"
#include "make_hashentry.f90.opari.inc"
#include "get_address.f90.opari.inc"
#include "get_node.f90.opari.inc"
#include "key_test.f90.opari.inc"
#include "get_next_node.f90.opari.inc"
#include "diagnose_tree.f90.opari.inc"
#include "check_table.f90.opari.inc"
#include "sum_lennardjones.f90.opari.inc"
#include "sum_bond.f90.opari.inc"
#include "draw_domains.f90.opari.inc"
#include "draw_tree2d.f90.opari.inc"
#include "draw_lists.f90.opari.inc"
#include "fields.f90.opari.inc"
#include "fields_p.f90.opari.inc"
#include "physvars.f90.opari.inc"
#include "pepcb.f90.opari.inc"
#include "setup.f90.opari.inc"
#include "setup_arrays.f90.opari.inc"
#include "stamp.f90.opari.inc"
#include "configure.f90.opari.inc"
#include "randion.f90.opari.inc"
#include "predef_parts.f90.opari.inc"
#include "maxwell1.f90.opari.inc"
#include "cold_start.f90.opari.inc"
#include "special_start.f90.opari.inc"
#include "constrain.f90.opari.inc"
#include "cutvector.f90.opari.inc"
#include "face.f90.opari.inc"
#include "scramble_v.f90.opari.inc"
#include "reset_ions.f90.opari.inc"
#include "add_electrons.f90.opari.inc"
#include "double_target.f90.opari.inc"
#include "laser.f90.opari.inc"
#include "beam.f90.opari.inc"
#include "beam_control.f90.opari.inc"
#include "beam_dust.f90.opari.inc"
#include "rezone.f90.opari.inc"
#include "mc_config.f90.opari.inc"
#include "velocities.f90.opari.inc"
#include "energy_cons.f90.opari.inc"
#include "potenergy.f90.opari.inc"
#include "kinenergy.f90.opari.inc"
#include "force_laser.f90.opari.inc"
#include "fpond.f90.opari.inc"
#include "empond.f90.opari.inc"
#include "emplane.f90.opari.inc"
#include "laser_bullet.f90.opari.inc"
#include "emoblique.f90.opari.inc"
#include "push_em.f90.opari.inc"
#include "push_full3v.f90.opari.inc"
#include "push.f90.opari.inc"
#include "reinject.f90.opari.inc"
#include "earth_plate.f90.opari.inc"
#include "add_ramp.f90.opari.inc"
#include "vis_parts_nbody.f90.opari.inc"
#include "vis_domains_nbody.f90.opari.inc"
#include "vis_fields.f90.opari.inc"
#include "dump.f90.opari.inc"
#include "param_dump.f90.opari.inc"
#include "diagnostics.f90.opari.inc"
#include "open_files.f90.opari.inc"
#include "close_files.f90.opari.inc"
#include "densities.f90.opari.inc"
#include "sum_fields.f90.opari.inc"
#include "dump_fields.f90.opari.inc"
#include "track_nc.f90.opari.inc"
#include "integrator.f90.opari.inc"

int POMP_MAX_ID = 16;

struct ompregdescr* pomp_rd_table[16] = {
  0,
  &omp_rd_1,
  &omp_rd_2,
  &omp_rd_3,
  &omp_rd_4,
  &omp_rd_5,
  &omp_rd_6,
  &omp_rd_7,
  &omp_rd_8,
  &omp_rd_9,
  &omp_rd_10,
  &omp_rd_11,
  &omp_rd_12,
  &omp_rd_13,
  &omp_rd_14,
  &omp_rd_15,
};
