#include "pomp_lib.h"


#include "treevars.f90.opari.inc"
#include "tree_utils.f90.opari.inc"
#include "utils.f90.opari.inc"
#include "tree_domains.f90.opari.inc"
#include "setup_treearrays.f90.opari.inc"
#include "tree_build.f90.opari.inc"
#include "tree_branches.f90.opari.inc"
#include "tree_fill.f90.opari.inc"
#include "tree_properties.f90.opari.inc"
#include "tree_walk.f90.opari.inc"
#include "tree_prefetch.f90.opari.inc"
#include "sum_force.f90.opari.inc"
#include "sum_bfield.f90.opari.inc"
#include "tree_update.f90.opari.inc"
#include "make_hashentry.f90.opari.inc"
#include "get_address.f90.opari.inc"
#include "get_node.f90.opari.inc"
#include "key_test.f90.opari.inc"
#include "get_next_node.f90.opari.inc"
#include "diagnose_tree.f90.opari.inc"
#include "check_table.f90.opari.inc"
#include "sum_lennardjones.f90.opari.inc"
#include "sum_bond.f90.opari.inc"
#include "draw_domains.f90.opari.inc"
#include "draw_tree2d.f90.opari.inc"
#include "draw_lists.f90.opari.inc"
#include "fields.f90.opari.inc"
#include "fields_p.f90.opari.inc"

int POMP_MAX_ID = 12;

struct ompregdescr* pomp_rd_table[12] = {
  0,
  &omp_rd_1,
  &omp_rd_2,
  &omp_rd_3,
  &omp_rd_4,
  &omp_rd_5,
  &omp_rd_6,
  &omp_rd_7,
  &omp_rd_8,
  &omp_rd_9,
  &omp_rd_10,
  &omp_rd_11,
};
